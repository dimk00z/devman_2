from transliterate import translit
from num2words import num2words
import re

speech = '''Ladies and gentlemen, I'm 78 years old and I finally got 15 minutes of fame once in a lifetime and I guess that this is mine. People have also told me to make these next few minutes escruciatingly embarrassing and to take vengeance of my enemies. Neither will happen.

More than 3 years ago I moved to Novo-Novsk, but worked on new Magnetic Storage for last 40. When I was 8...'''

speech_on_rus_translit = translit(speech, 'ru')
print(speech_on_rus_translit)
digits_in_speech = re.findall(r'\b\d+\b', speech)
for digit_in_speech in digits_in_speech:
  digit_in_rus_translit = translit(num2words(digit_in_speech), 'ru')
  print(digit_in_speech,'—',digit_in_rus_translit)
