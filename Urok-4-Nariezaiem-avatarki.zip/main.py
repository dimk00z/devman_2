from PIL import Image

BLEND_NUMBER = 25
THUMBNAIL_MAX_SIDE = 80


def get_image_with_effect(red_channel,
                          green_channel,
                          blue_channel):
    coordinates_for_red_crop = (0, 0,
                                red_channel.width-BLEND_NUMBER * 2,
                                red_channel.height)
    cropped_red_image = red_channel.crop(coordinates_for_red_crop)
    coordinates_for_green_crop = (BLEND_NUMBER, 0,
                                  green_channel.width - BLEND_NUMBER,
                                  green_channel.height)
    cropped_green_image = green_channel.crop(coordinates_for_green_crop)
    coordinates_for_blue_crop = (BLEND_NUMBER * 2, 0,
                                 blue_channel.width,
                                 blue_channel.height)
    cropped_blue_image = blue_channel.crop(coordinates_for_blue_crop)
    result_image = Image.merge('RGB',
                               (cropped_red_image,
                                cropped_green_image,
                                cropped_blue_image))
    return result_image


image = Image.open('test_image.jpg')
if image.mode != 'RGB':
    image = image.convert('RGB')
red_channel, green_channel, blue_channel = image.split()
result_image = get_image_with_effect(red_channel,
                                     green_channel,
                                     blue_channel)
result_image.thumbnail((THUMBNAIL_MAX_SIDE,
                        THUMBNAIL_MAX_SIDE))
result_image.save('image_thumbnail_with_effect.jpg')
