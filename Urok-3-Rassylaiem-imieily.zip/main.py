import smtplib
import os
SENDER_EMAIL = 'skywalker.any@yandex.ru'
SENDER_NAME = 'Any_Skywalker'
SITE_NAME_FOR_SUBCRIBING = 'dvmn.org'
EMAIL_TEMPLATE = '''Привет, %friend_name%! %my_name% приглашает тебя на сайт %website%!

%website% — это новая версия онлайн-курса по программированию. 
Изучаем Python и не только. Решаем задачи. Получаем ревью от преподавателя. 

Как будет проходить ваше обучение на %website%? 

→ Попрактикуешься на реальных кейсах. 
Задачи от тимлидов со стажем от 10 лет в программировании.
→ Будешь учиться без стресса и бессонных ночей. 
Задачи не «сгорят» и не уйдут к другому. Занимайся в удобное время и ровно столько, сколько можешь.
→ Подготовишь крепкое резюме.
Все проекты — они же решение наших задачек — можно разместить на твоём GitHub. Работодатели такое оценят. 

Регистрируйся → %website%  
На модули, которые еще не вышли, можно подписаться и получить уведомление о релизе сразу на имейл.'''


def create_email_for_sending(email_template, site_name,
                             subscriber_name, subscriber_email,
                             sender_email, sender_name):
    email_header = '''From:{0}\nTo:{1}\nSubject:'''.format(sender_email,
                                                           subscriber_email)
    email_body = email_template.replace('%website%', site_name)
    email_body = email_body.replace('%friend_name%', subscriber_name)
    email_body = email_body.replace('%my_name%', sender_name)
    email_for_sending = email_header + email_body
    return email_for_sending.encode("UTF-8")


def send_email(email_text, smtp_adress, login,
               password, subscriber_email, sender_email):
    try:
        server = smtplib.SMTP_SSL(smtp_adress)
        server.login(login, password)
        server.sendmail(sender_email, subscriber_email, email_text)
        server.quit()
        print("Successfully sent email to {0}".format(subscriber_email))
    except smtplib.SMTPException:
        print("Error: unable to send email")

friends = []
friends.append(['Dmitriy', 'dimk00z@gmail.com'])
password_for_smtp = os.getenv("PASSWORD_FOR_SMTP")
login_for_smtp = os.getenv("LOGIN_FOR_SMTP")
for friend_name, friend_email in friends:
    email_for_sending = create_email_for_sending(EMAIL_TEMPLATE,
                                                 SITE_NAME_FOR_SUBCRIBING,
                                                 friend_name, friend_email,
                                                 SENDER_EMAIL, SENDER_NAME)
    send_email(email_for_sending, 'smtp.yandex.ru:465',
               login_for_smtp, password_for_smtp,
               friend_email, SENDER_EMAIL)
