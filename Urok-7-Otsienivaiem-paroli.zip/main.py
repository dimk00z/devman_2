import re


def has_digit(password):
    return any(letter.isdigit() for letter in password)


def is_very_long(password):
  return len(password)>12


def has_letters(password):
  return any(letter.isalpha() for letter in password)


def has_upper_letters(password):
  return any(letter.isupper() for letter in password) 

def has_lower_letters(password):
  return any(letter.islower() for letter in password) 

def has_symbols(password):
  regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
  return regex.search(password) 
def has_not_only_symbols(password):
  return has_symbols(password) and (has_letters(password) or has_digit(password))
password = input('Введите пароль:')
print(password)
if len(password)>12:
  print('Длинный пароль')
else:
  print('Короткий пароль')
for letter in password:
  if letter.isdigit():
    print(f'{letter} - цифра')
  if letter.isalpha():
    print(f'{letter} - буква')

print(has_digit(password))
print(is_very_long(password))

score = 0
password_checks=[
  has_digit, is_very_long, has_letters, has_upper_letters, has_lower_letters, has_symbols
]
for check in password_checks:
  if check(password):
    score+=2
print(score)