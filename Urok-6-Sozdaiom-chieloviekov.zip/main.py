import file_operations
from faker import Faker
import random
import os

LOWER_BOUND = 8
UPPER_BOUND = 14
RUNIC_ALPHABET = {
    'а': 'а͠', 'б': 'б̋', 'в': 'в͒͠',
    'г': 'г͒͠', 'д': 'д̋', 'е': 'е͠',
    'ё': 'ё͒͠', 'ж': 'ж͒', 'з': 'з̋̋͠',
    'и': 'и', 'й': 'й͒͠', 'к': 'к̋̋',
    'л': 'л̋͠', 'м': 'м͒͠', 'н': 'н͒',
    'о': 'о̋', 'п': 'п̋͠', 'р': 'р̋͠',
    'с': 'с͒', 'т': 'т͒', 'у': 'у͒͠',
    'ф': 'ф̋̋͠', 'х': 'х͒͠', 'ц': 'ц̋',
    'ч': 'ч̋͠', 'ш': 'ш͒͠', 'щ': 'щ̋',
    'ъ': 'ъ̋͠', 'ы': 'ы̋͠', 'ь': 'ь̋',
    'э': 'э͒͠͠', 'ю': 'ю̋͠', 'я': 'я̋',
    'А': 'А͠', 'Б': 'Б̋', 'В': 'В͒͠',
    'Г': 'Г͒͠', 'Д': 'Д̋', 'Е': 'Е',
    'Ё': 'Ё͒͠', 'Ж': 'Ж͒', 'З': 'З̋̋͠',
    'И': 'И', 'Й': 'Й͒͠', 'К': 'К̋̋',
    'Л': 'Л̋͠', 'М': 'М͒͠', 'Н': 'Н͒',
    'О': 'О̋', 'П': 'П̋͠', 'Р': 'Р̋͠',
    'С': 'С͒', 'Т': 'Т͒', 'У': 'У͒͠',
    'Ф': 'Ф̋̋͠', 'Х': 'Х͒͠', 'Ц': 'Ц̋',
    'Ч': 'Ч̋͠', 'Ш': 'Ш͒͠', 'Щ': 'Щ̋',
    'Ъ': 'Ъ̋͠', 'Ы': 'Ы̋͠', 'Ь': 'Ь̋',
    'Э': 'Э͒͠͠', 'Ю': 'Ю̋͠', 'Я': 'Я̋',
    ' ': ' '
}
SKILLS_LIST = ["Стремительный прыжок",
               "Электрический выстрел",
               "Ледяной удар",
               "Стремительный удар",
               "Кислотный взгляд",
               "Тайный побег",
               "Ледяной выстрел",
               "Огненный заряд"]


def get_runic_skills(skills):
    runic_skills = []
    for skill in skills:
        for letter, runic_letter in RUNIC_ALPHABET.items():
            skill = skill.replace(letter, runic_letter)
        runic_skills.append(skill)
    return runic_skills


def get_random_skills():
    return random.sample(SKILLS_LIST, k=3)


def get_random_chr():
    return random.randint(LOWER_BOUND, UPPER_BOUND)


def create_fake_person():
    fake = Faker("ru_RU")
    is_female = random.choice([True, False])
    if is_female:
        character_name = fake.first_name_female()
        character_last_name = fake.last_name_female()
    else:
        character_name = fake.first_name_male()
        character_last_name = fake.last_name_male()
    runic_skills = get_runic_skills(get_random_skills())
    context = {
        "first_name": character_name,
        "last_name": character_last_name,
        "job": fake.job(),
        "town": fake.city(),
        "strength": get_random_chr(),
        "agility": get_random_chr(),
        "endurance": get_random_chr(),
        "intelligence": get_random_chr(),
        "luck": get_random_chr(),
        "skill_1": runic_skills[0],
        "skill_2": runic_skills[1],
        "skill_3": runic_skills[2]}
    return context


def create_char_files(file_count):
    for out_put_file_number in range(file_count):
        template_file_name = 'charsheets/charsheet.svg'
        out_put_dir = os.path.split(
            os.path.abspath(template_file_name))[0]
        output_file_name = os.path.join(out_put_dir,
                                        f'charsheet_{out_put_file_number}.svg')
        file_operations.render_template(
            template_file_name,
            output_file_name,
            create_fake_person())

create_char_files(10)
