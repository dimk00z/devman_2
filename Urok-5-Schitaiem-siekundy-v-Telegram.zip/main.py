import ptbot
import os
from pytimeparse import parse

BOT_TOKEN = os.getenv("BOT_TOKEN")
ID_FOR_SEND = os.getenv("USER_ID")


def render_progressbar(total, iteration, prefix='', suffix='',
                       length=30, fill='█', zfill='░'):
    iteration = min(total, iteration)
    percent = "{0:.1f}"
    percent = percent.format(100 * (iteration / float(total)))
    filled_length = int(length * iteration // total)
    pbar = fill * filled_length + zfill * (length - filled_length)
    return '{0} |{1}| {2}% {3}'.format(prefix, pbar, percent, suffix)


def send_telegram_message(text_for_send):
    return bot.send_message(
        ID_FOR_SEND,
        text_for_send)


def notify_progress(secs_left, message_id, total_seconds):
    progress_bas_status = render_progressbar(total_seconds, secs_left)
    bot.update_message(
        ID_FOR_SEND,
        message_id,
        f'''
Осталось {secs_left} секунд(ы)
{progress_bas_status}''')


def set_timer(seconds):
    parsed_seconds = parse(seconds)
    message_id = send_telegram_message(
        f'Таймер запущен на {parsed_seconds} секунд(ы)')
    bot.create_countdown(parsed_seconds,
                         notify_progress,
                         message_id=message_id,
                         total_seconds=parsed_seconds)
    bot.create_timer(parsed_seconds, send_telegram_message, 'Время вышло!')


bot = ptbot.Bot(BOT_TOKEN)
send_telegram_message('''Бот запущен!
На сколько запустить таймер?''')
bot.wait_for_msg(set_timer)
