import json
import requests
import os
from geopy import distance
import folium
from flask import Flask

MAP_FILE_NAME = 'map.html'
NEAREST_BARS_AMOUNT = 5


def get_map_file():
    with open(MAP_FILE_NAME) as file:
        return file.read()


def get_bar_distance(bar):
    return bar['distance']


def fetch_coordinates(apikey, place):
    base_url = "https://geocode-maps.yandex.ru/1.x"
    params = {"geocode": place, "apikey": apikey, "format": "json"}
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    places_found = response.json(
    )['response']['GeoObjectCollection']['featureMember']
    most_relevant = places_found[0]
    lon, lat = most_relevant['GeoObject']['Point']['pos'].split(" ")
    return lon, lat


def create_map_with_bars(location_title,
                         location_latitude,
                         location_longitude,
                         nearest_bars):
    map_with_bars = folium.Map(location=[location_latitude,
                                         location_longitude],
                               zoom_start=14)
    for near_bar in nearest_bars:
        folium.Marker(
            location=[near_bar['latitude'], near_bar['longitude']],
            popup=near_bar['title']).add_to(map_with_bars)
    map_with_bars.save(MAP_FILE_NAME)


def get_distance(first_coordinates,
                 second_coordinates):
    return distance.distance(first_coordinates, second_coordinates).km


with open("data-2897-2019-01-22.json", "r", encoding="CP1251") as my_file:
    bars_json = my_file.read()
bars_from_file = json.loads(bars_json)
api_key = os.getenv("API_KEY")
location_title = input('Где вы находитесь? ')
location_longitude, location_latitude = fetch_coordinates(api_key,
                                                          location_title)
bars_with_distance_to_point = []
for bar in bars_from_file:
    bar_name = bar['Name']
    bar_longitude = bar['geoData']['coordinates'][0]
    bar_latitude = bar['geoData']['coordinates'][1]
    distace_to_bar = get_distance((bar_latitude, bar_longitude),
                                  (location_latitude, location_longitude))
    bars_with_distance_to_point.append({
        'distance': distace_to_bar,
        'latitude': bar_latitude,
        'longitude': bar_longitude,
        'title': bar_name
    })

nearest_bars = sorted(bars_with_distance_to_point, key=get_bar_distance)
nearest_bars = nearest_bars[:NEAREST_BARS_AMOUNT]
create_map_with_bars(location_title,
                     location_latitude,
                     location_longitude,
                     nearest_bars)
app = Flask(__name__)
app.add_url_rule('/', 'nearest_bars_map', get_map_file)
app.run('0.0.0.0')
